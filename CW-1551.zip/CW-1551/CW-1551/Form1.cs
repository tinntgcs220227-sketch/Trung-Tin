﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace CW_1551
{
    public partial class Form1 : Form
    {
        // ===========================================================================
        // TASK 3: DATA STRUCTURES [cite: 78, 81]
        // Using a List to store an unknown number of Person objects.
        // ===========================================================================
        private List<Person> database = new List<Person>();
        private bool isClickingGrid = false; // Flag to prevent UI conflicts during selection

        public Form1()
        {
            InitializeComponent();
        }

        // ===========================================================================
        // FUNCTIONALITY: ADD NEW DATA [cite: 40]
        // This method handles the creation of new user records based on selected role.
        // ===========================================================================
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string role = cmbRole.Text;
                string name = txtName.Text;
                string tel = txtTel.Text;
                string email = txtEmail.Text;

                // Basic validation: Name is mandatory [cite: 25]
                if (string.IsNullOrWhiteSpace(name))
                {
                    MessageBox.Show("Please enter a Name!");
                    return;
                }

                 if (role == "Teacher") // [cite: 30]
                {
                    // Teacher requires Salary and 2 subjects [cite: 31, 32]
                    database.Add(new Teacher(name, tel, email,
                        Convert.ToDouble(txtSalary.Text),
                        GetSub(txtSubjects.Text, 0), GetSub(txtSubjects.Text, 1)));
                }
                else if (role == "Admin") // 
                {
                    // Admin requires Salary, Employment Type, and Working Hours 
                    database.Add(new Admin(name, tel, email,
                        Convert.ToDouble(txtSalary.Text),
                        txtType.Text,
                        string.IsNullOrWhiteSpace(txtHours.Text) ? 0 : Convert.ToInt32(txtHours.Text)));
                }
                else if (role == "Student") // [cite: 37]
                {
                    // Student requires 3 subjects only 
                    database.Add(new Student(name, tel, email,
                        GetSub(txtSubjects.Text, 0), GetSub(txtSubjects.Text, 1), GetSub(txtSubjects.Text, 2)));
                }
                else
                {
                    MessageBox.Show("Please select a Role!"); return;
                }

                MessageBox.Show("Data added successfully!");
                RefreshData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Input error! Ensure numeric fields are correct.\n" + ex.Message);
            }
        }

        // ===========================================================================
        // FUNCTIONALITY: EDIT EXISTING DATA [cite: 43]
        // Updates the selected record without losing group-specific data.
        // ===========================================================================
        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvData.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select a row to edit!"); return;
            }

            try
            {
                string oldName = dgvData.SelectedRows[0].Cells["Name"].Value.ToString();
                Person p = database.FirstOrDefault(x => x.Name == oldName);

                if (p != null)
                {
                    // Update basic data [cite: 24]
                    p.Name = txtName.Text;
                    p.Telephone = txtTel.Text;
                    p.Email = txtEmail.Text;

                    // Update group-specific data [cite: 29]
                    if (p is Teacher t)
                    {
                        t.Salary = Convert.ToDouble(txtSalary.Text);
                        t.Subject1 = GetSub(txtSubjects.Text, 0); t.Subject2 = GetSub(txtSubjects.Text, 1);
                    }
                    else if (p is Admin a)
                    {
                        a.Salary = Convert.ToDouble(txtSalary.Text);
                        a.WorkingType = txtType.Text;
                        a.WorkingHours = string.IsNullOrWhiteSpace(txtHours.Text) ? 0 : Convert.ToInt32(txtHours.Text);
                    }
                    else if (p is Student s)
                    {
                        s.Subject1 = GetSub(txtSubjects.Text, 0); s.Subject2 = GetSub(txtSubjects.Text, 1); s.Subject3 = GetSub(txtSubjects.Text, 2);
                    }

                    MessageBox.Show("Record updated!");
                    RefreshData();
                }
            }
            catch (Exception ex) { MessageBox.Show("Edit error: " + ex.Message); }
        }

        // ===========================================================================
        // FUNCTIONALITY: VIEW DATA & VIEW BY GROUP [cite: 41, 42]
        // Refreshes the grid display using LINQ for filtering and polymorphism.
        // ===========================================================================
        private void RefreshData()
        {
            if (database == null) return;
            string filterRole = cmbRole.Text;
            dgvData.DataSource = null;

            var displayList = database.Where(p => filterRole == "All" || p.Role == filterRole)
                                      .Select(p => {
                                          string sal = ""; string sub = ""; string typ = ""; string hrs = "";
                                          if (p is Teacher t) { sal = t.Salary.ToString(); sub = $"{t.Subject1}, {t.Subject2}".Trim(',', ' '); }
                                          else if (p is Admin a) { sal = a.Salary.ToString(); typ = a.WorkingType; hrs = a.WorkingHours.ToString(); }
                                          else if (p is Student s) { sub = $"{s.Subject1}, {s.Subject2}, {s.Subject3}".Trim(',', ' '); }

                                          return new { p.Name, p.Telephone, p.Email, p.Role, Salary = sal, Subjects = sub, Type = typ, Hours = hrs };
                                      }).ToList();
            dgvData.DataSource = displayList;
        }

        // ===========================================================================
        // UI LOGIC: CLICK TO SELECT
        // Fills the textboxes with selected record data for editing.
        // ===========================================================================
        private void dgvData_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                isClickingGrid = true;
                DataGridViewRow row = dgvData.Rows[e.RowIndex];
                txtName.Text = row.Cells["Name"].Value?.ToString() ?? "";
                txtTel.Text = row.Cells["Telephone"].Value?.ToString() ?? "";
                txtEmail.Text = row.Cells["Email"].Value?.ToString() ?? "";
                cmbRole.Text = row.Cells["Role"].Value?.ToString() ?? "";
                txtSalary.Text = row.Cells["Salary"].Value?.ToString() ?? "";
                txtSubjects.Text = row.Cells["Subjects"].Value?.ToString() ?? "";
                txtType.Text = row.Cells["Type"].Value?.ToString() ?? "";
                txtHours.Text = row.Cells["Hours"].Value?.ToString() ?? "";
                isClickingGrid = false;
            }
        }

        private void cmbRole_SelectedIndexChanged(object sender, EventArgs e)
        {
            string role = cmbRole.Text;
            // Toggle visibility based on Role requirements [cite: 30-38]
            txtSalary.Visible = (role == "Teacher" || role == "Admin");
            txtHours.Visible = (role == "Admin");
            txtType.Visible = (role == "Admin"); // Admin specific [cite: 35]
            txtSubjects.Visible = (role == "Teacher" || role == "Student"); // Admin has no subjects in doc 

            if (!isClickingGrid) RefreshData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvData.SelectedRows.Count > 0)
            {
                database.RemoveAt(dgvData.SelectedRows[0].Index); // [cite: 44]
                RefreshData();
                MessageBox.Show("Record deleted!");
            }
        }

        private void btnExit_Click(object sender, EventArgs e) { Application.Exit(); } // [cite: 82]

        private string GetSub(string input, int index)
        {
            if (string.IsNullOrEmpty(input)) return "";
            string[] subs = input.Split(',');
            return subs.Length > index ? subs[index].Trim() : "";
        }
    }

    // ===========================================================================
    // TASK 3: OOP IMPLEMENTATION (ENCAPSULATION, INHERITANCE, POLYMORPHISM) [cite: 79]
    // ===========================================================================

    
    public abstract class Person // Base class [cite: 79]
    {
        public string Name { get; set; }
        public string Telephone { get; set; }
        public string Email { get; set; }
        public string Role { get; set; }

        public Person(string name, string tel, string email, string role)
        {
            Name = name; Telephone = tel; Email = email; Role = role;
        }
        public abstract string GetDetails(); // Abstract method for polymorphism
    }

    
    public class Teacher : Person // Derived class [cite: 79, 30]
    {
        public double Salary { get; set; } // [cite: 31]
        public string Subject1 { get; set; } // [cite: 32]
        public string Subject2 { get; set; }
        public Teacher(string name, string tel, string email, double sal, string s1, string s2)
            : base(name, tel, email, "Teacher") { Salary = sal; Subject1 = s1; Subject2 = s2; }
        public override string GetDetails() => $"Salary: {Salary}, Subjects: {Subject1}, {Subject2}";
    }

    
    public class Admin : Person // Derived class [cite: 79, 33]
    {
        public double Salary { get; set; } // [cite: 34]
        public string WorkingType { get; set; } // Full-time/Part-time [cite: 35]
        public int WorkingHours { get; set; } // [cite: 36]
        public Admin(string name, string tel, string email, double sal, string type, int hours)
            : base(name, tel, email, "Admin") { Salary = sal; WorkingType = type; WorkingHours = hours; }
        public override string GetDetails() => $"Salary: {Salary}, Type: {WorkingType}, Hours: {WorkingHours}";
    }

    
    public class Student : Person // Derived class [cite: 79, 37]
    {
        public string Subject1 { get; set; } // 
        public string Subject2 { get; set; }
        public string Subject3 { get; set; }
        public Student(string name, string tel, string email, string s1, string s2, string s3)
            : base(name, tel, email, "Student") { Subject1 = s1; Subject2 = s2; Subject3 = s3; }
        public override string GetDetails() => $"Subjects: {Subject1}, {Subject2}, {Subject3}";
    }
}