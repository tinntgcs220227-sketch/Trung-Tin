﻿namespace CW_1551
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbRole = new ComboBox();
            txtName = new TextBox();
            txtTel = new TextBox();
            txtEmail = new TextBox();
            txtSalary = new TextBox();
            txtSubjects = new TextBox();
            txtHours = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            lblSalary = new Label();
            lblSubjects = new Label();
            lblHours = new Label();
            dgvData = new DataGridView();
            btnAdd = new Button();
            btnEdit = new Button();
            btnDelete = new Button();
            btnExit = new Button();
            txtType = new TextBox();
            lblType = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvData).BeginInit();
            SuspendLayout();
            // 
            // cmbRole
            // 
            cmbRole.FormattingEnabled = true;
            cmbRole.Items.AddRange(new object[] { "All", "Admin", "Teacher", "Student" });
            cmbRole.Location = new Point(70, 52);
            cmbRole.Name = "cmbRole";
            cmbRole.Size = new Size(121, 23);
            cmbRole.TabIndex = 0;
            cmbRole.SelectedIndexChanged += cmbRole_SelectedIndexChanged;
            // 
            // txtName
            // 
            txtName.Location = new Point(70, 108);
            txtName.Name = "txtName";
            txtName.Size = new Size(100, 23);
            txtName.TabIndex = 1;
            // 
            // txtTel
            // 
            txtTel.Location = new Point(70, 149);
            txtTel.Name = "txtTel";
            txtTel.Size = new Size(100, 23);
            txtTel.TabIndex = 2;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(70, 199);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(100, 23);
            txtEmail.TabIndex = 3;
            // 
            // txtSalary
            // 
            txtSalary.Location = new Point(70, 251);
            txtSalary.Name = "txtSalary";
            txtSalary.Size = new Size(100, 23);
            txtSalary.TabIndex = 4;
            // 
            // txtSubjects
            // 
            txtSubjects.Location = new Point(70, 302);
            txtSubjects.Name = "txtSubjects";
            txtSubjects.Size = new Size(100, 23);
            txtSubjects.TabIndex = 5;
            // 
            // txtHours
            // 
            txtHours.Location = new Point(70, 351);
            txtHours.Name = "txtHours";
            txtHours.Size = new Size(100, 23);
            txtHours.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 116);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 7;
            label1.Text = "Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(2, 157);
            label2.Name = "label2";
            label2.Size = new Size(62, 15);
            label2.TabIndex = 8;
            label2.Text = "Telephone";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 207);
            label3.Name = "label3";
            label3.Size = new Size(36, 15);
            label3.TabIndex = 9;
            label3.Text = "Email";
            // 
            // lblSalary
            // 
            lblSalary.AutoSize = true;
            lblSalary.Location = new Point(12, 259);
            lblSalary.Name = "lblSalary";
            lblSalary.Size = new Size(38, 15);
            lblSalary.TabIndex = 10;
            lblSalary.Text = "Salary";
            // 
            // lblSubjects
            // 
            lblSubjects.AutoSize = true;
            lblSubjects.Location = new Point(12, 310);
            lblSubjects.Name = "lblSubjects";
            lblSubjects.Size = new Size(51, 15);
            lblSubjects.TabIndex = 11;
            lblSubjects.Text = "Subjects";
            // 
            // lblHours
            // 
            lblHours.AutoSize = true;
            lblHours.Location = new Point(12, 359);
            lblHours.Name = "lblHours";
            lblHours.Size = new Size(39, 15);
            lblHours.TabIndex = 12;
            lblHours.Text = "Hours";
            // 
            // dgvData
            // 
            dgvData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvData.Location = new Point(192, 3);
            dgvData.Name = "dgvData";
            dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvData.Size = new Size(606, 406);
            dgvData.TabIndex = 13;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(338, 415);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(75, 23);
            btnAdd.TabIndex = 18;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(437, 415);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(75, 23);
            btnEdit.TabIndex = 19;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(539, 415);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(75, 23);
            btnDelete.TabIndex = 20;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(644, 415);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(75, 23);
            btnExit.TabIndex = 21;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // txtType
            // 
            txtType.Location = new Point(70, 397);
            txtType.Name = "txtType";
            txtType.Size = new Size(100, 23);
            txtType.TabIndex = 22;
            // 
            // lblType
            // 
            lblType.AutoSize = true;
            lblType.Location = new Point(12, 405);
            lblType.Name = "lblType";
            lblType.Size = new Size(32, 15);
            lblType.TabIndex = 23;
            lblType.Text = "Type";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblType);
            Controls.Add(txtType);
            Controls.Add(btnExit);
            Controls.Add(btnDelete);
            Controls.Add(btnEdit);
            Controls.Add(btnAdd);
            Controls.Add(dgvData);
            Controls.Add(lblHours);
            Controls.Add(lblSubjects);
            Controls.Add(lblSalary);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtHours);
            Controls.Add(txtSubjects);
            Controls.Add(txtSalary);
            Controls.Add(txtEmail);
            Controls.Add(txtTel);
            Controls.Add(txtName);
            Controls.Add(cmbRole);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dgvData).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbRole;
        private TextBox txtName;
        private TextBox txtTel;
        private TextBox txtEmail;
        private TextBox txtSalary;
        private TextBox txtSubjects;
        private TextBox txtHours;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label lblSalary;
        private Label lblSubjects;
        private Label lblHours;
        private DataGridView dgvData;
        private Button btnAdd;
        private Button btnEdit;
        private Button btnDelete;
        private Button btnExit;
        private TextBox txtType;
        private Label lblType;
    }
}
