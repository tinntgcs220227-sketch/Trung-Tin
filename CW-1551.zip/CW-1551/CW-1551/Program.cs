﻿using System;
using System.Windows.Forms;

namespace CW_1551
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Dòng này gọi Form1 của bạn lên khi chạy ứng dụng
            Application.Run(new Form1());
        }
    }
}